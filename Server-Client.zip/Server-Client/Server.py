# This Python file uses the following encoding: utf-8
import socket
import whois
import datetime


# host ve port berliner
port = 5000


def server_program():
    try:
        # socket create.
        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        print("socket oluşturuldu")
        s.bind(((socket.gethostname()), port))  # bind host address and port together
        print("socket {} nolu porta bağlandı".format(port))
        # configure how many client the server can listen simultaneously
        s.listen(5)
        print("socket dinleniyor")
        conn, address = s.accept()  # accept new connection
        print("Connection from: " + str(address))  # connection info print
        infoadress = str(address)
        info = str(whois.whois(socket.gethostname()))
        datetime.datetime(2009, 1, 6, 15, 8, 24, 78915)
        date = str(datetime.datetime.now())
        # create file
        file = open('info.txt', 'a')
        # Address, user client information, date and time information are written to the created file.
        file.writelines(
            "Adress Bilgisi:" + infoadress + "\n" + "Client Bilgisi:" + info + "\n" + "Tarih:" + date + "\n")

        # close file
        file.close()
        while True:
            # take request from client
            data = conn.recv(1024).decode()
            # # This data is compared with the desire of the user to take action.
            # If # data is T, the sum of the digits entered is calculated. If F is redirected to the factorial account.
            if data == "T":
                data = " Toplama icin sayi giriniz"
                conn.send(data.encode('utf-8'))  # send data to the client
                data1 = conn.recv(1024).decode()
                sayi = int(data1)
                total = 0
                while sayi > 0:
                    k = sayi % 10
                    total = total + k
                    sayi = sayi // 10
                total = str(total)
                message = "Toplam icin T faktoriyel hesap icin F ye basın sonlandırmak için ise S bas"
                # totol send client
                conn.send(("sonuc: " + total + "\n" + message).encode('utf-8'))
            elif data == "F":
                data = " faktoriyel icin sayi giriniz"
                conn.send(data.encode('utf-8'))
                data2 = conn.recv(1024).decode()
                say2 = int(data2)
                if int(say2) >= 0:
                    f = 1
                    a = int(say2)
                    while a >= 2:
                        f = f * a
                        a -= 1
                        sonuc = str(f)
                message = "Toplam icin T faktoriyel hesap icin F ye basın sonlandırmak için ise S bas"
                conn.send(("sonuc: " + sonuc + "\n" + message).encode('utf-8'))

            elif data == "S":
                # data== S close socket
                s.close()

    except socket.error as msg:
        # socket is error print error
        print("Hata:", msg)


# call function
if __name__ == '__main__':
    server_program()
