# This Python file uses the following encoding: utf-8
import socket
import time

import datetime


def client_program():
    # as both code is running on same pc
    port = 5000  # socket server port number

    client_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    client_socket.connect(((socket.gethostname()), port))
    print("Toplam icin T faktoriyel hesap icin F ye basın sonlandırmak için ise S bas \n")
    message = input(" -> ")
    while message != "S":
        time1 = time.time_ns()  # get time as nanosecond
        file = open('time.txt', 'a')
        file.writelines("Istek süresi:" + str(time1) + "\n")
        client_socket.send(message.encode())  # send request
        data = client_socket.recv(1024).decode()  # receive data stream.
        # create file and print request time and response time in that file
        print('Server dan gelen cevap : ' + data)  # show in terminal
        time2 = time.time_ns()
        file.writelines("Cevap Süresi: " + str(time2) + "\n")

        file.close()
        message = input(" -> ")  # again input data
        if data == "S":
            client_socket.close()

        # client_socket.close()


if __name__ == '__main__':
    client_program()
else:
    client_program()
